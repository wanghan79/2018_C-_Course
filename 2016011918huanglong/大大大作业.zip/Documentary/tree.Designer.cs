﻿namespace Documentary
{
    partial class DocumentControlSys
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewGroup listViewGroup1 = new System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left);
            this.label_filetree = new System.Windows.Forms.Label();
            this.viewtree_Documenttree = new System.Windows.Forms.TreeView();
            this.filetree_Processlist = new System.Windows.Forms.ListView();
            this.headerfile = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.headerchange = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.headertime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.headeruser = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.affirm = new System.Windows.Forms.Button();
            this.Pathtxt = new System.Windows.Forms.TextBox();
            this.Shrubtimer = new System.Windows.Forms.Timer(this.components);
            this.label_import = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_filetree
            // 
            this.label_filetree.AutoSize = true;
            this.label_filetree.Font = new System.Drawing.Font("微软雅黑", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_filetree.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_filetree.Location = new System.Drawing.Point(230, 10);
            this.label_filetree.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_filetree.Name = "label_filetree";
            this.label_filetree.Size = new System.Drawing.Size(278, 39);
            this.label_filetree.TabIndex = 0;
            this.label_filetree.Text = "文件系统树状图监控";
            this.label_filetree.Click += new System.EventHandler(this.Titellab_Click);
            // 
            // viewtree_Documenttree
            // 
            this.viewtree_Documenttree.LabelEdit = true;
            this.viewtree_Documenttree.Location = new System.Drawing.Point(12, 164);
            this.viewtree_Documenttree.Name = "viewtree_Documenttree";
            this.viewtree_Documenttree.Size = new System.Drawing.Size(300, 200);
            this.viewtree_Documenttree.TabIndex = 1;
            this.viewtree_Documenttree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.Documenttree_AfterSelect);
            // 
            // filetree_Processlist
            // 
            this.filetree_Processlist.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.headerfile,
            this.headerchange,
            this.headertime,
            this.headeruser});
            listViewGroup1.Header = "ListViewGroup";
            listViewGroup1.Name = "listViewGroup1";
            this.filetree_Processlist.Groups.AddRange(new System.Windows.Forms.ListViewGroup[] {
            listViewGroup1});
            this.filetree_Processlist.Location = new System.Drawing.Point(338, 164);
            this.filetree_Processlist.Name = "filetree_Processlist";
            this.filetree_Processlist.RightToLeftLayout = true;
            this.filetree_Processlist.Size = new System.Drawing.Size(410, 200);
            this.filetree_Processlist.TabIndex = 2;
            this.filetree_Processlist.UseCompatibleStateImageBehavior = false;
            this.filetree_Processlist.UseWaitCursor = true;
            this.filetree_Processlist.View = System.Windows.Forms.View.Details;
            this.filetree_Processlist.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // headerfile
            // 
            this.headerfile.Text = "文件名";
            this.headerfile.Width = 100;
            // 
            // headerchange
            // 
            this.headerchange.Text = "修改操作";
            this.headerchange.Width = 100;
            // 
            // headertime
            // 
            this.headertime.Text = "时间";
            this.headertime.Width = 100;
            // 
            // headeruser
            // 
            this.headeruser.Text = "用户";
            this.headeruser.Width = 100;
            // 
            // affirm
            // 
            this.affirm.Location = new System.Drawing.Point(546, 83);
            this.affirm.Name = "affirm";
            this.affirm.Size = new System.Drawing.Size(74, 36);
            this.affirm.TabIndex = 3;
            this.affirm.Text = "确认";
            this.affirm.UseVisualStyleBackColor = true;
            this.affirm.Click += new System.EventHandler(this.OKbtn_Click);
            // 
            // Pathtxt
            // 
            this.Pathtxt.Location = new System.Drawing.Point(187, 83);
            this.Pathtxt.Name = "Pathtxt";
            this.Pathtxt.Size = new System.Drawing.Size(330, 29);
            this.Pathtxt.TabIndex = 4;
            this.Pathtxt.TextChanged += new System.EventHandler(this.Pathtxt_TextChanged);
            // 
            // Shrubtimer
            // 
            this.Shrubtimer.Enabled = true;
            this.Shrubtimer.Interval = 1000;
            this.Shrubtimer.Tick += new System.EventHandler(this.Shrubtimer_Tick);
            // 
            // label_import
            // 
            this.label_import.AutoSize = true;
            this.label_import.Location = new System.Drawing.Point(87, 83);
            this.label_import.Name = "label_import";
            this.label_import.Size = new System.Drawing.Size(42, 22);
            this.label_import.TabIndex = 5;
            this.label_import.Text = "路径";
            // 
            // DocumentControlSys
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 392);
            this.Controls.Add(this.label_import);
            this.Controls.Add(this.Pathtxt);
            this.Controls.Add(this.affirm);
            this.Controls.Add(this.filetree_Processlist);
            this.Controls.Add(this.viewtree_Documenttree);
            this.Controls.Add(this.label_filetree);
            this.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "DocumentControlSys";
            this.Text = "文件系统树状图监控";
            this.Load += new System.EventHandler(this.DocumentControlSys_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_filetree;
        private System.Windows.Forms.TreeView viewtree_Documenttree;
        private System.Windows.Forms.ListView filetree_Processlist;
        private System.Windows.Forms.Button affirm;
        private System.Windows.Forms.TextBox Pathtxt;
        private System.Windows.Forms.ColumnHeader headerfile;
        private System.Windows.Forms.ColumnHeader headerchange;
        private System.Windows.Forms.ColumnHeader headertime;
        private System.Windows.Forms.ColumnHeader headeruser;
        private System.Windows.Forms.Timer Shrubtimer;
        private System.Windows.Forms.Label label_import;
    }
}

